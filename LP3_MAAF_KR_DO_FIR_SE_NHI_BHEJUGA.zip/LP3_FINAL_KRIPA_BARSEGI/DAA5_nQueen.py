def isSafe(mat, row, col, n):
    """
    Check whether placing a queen at (row, col) conflicts with any existing queen
    anywhere on the board. This checks rows, columns and diagonals.
    """
    for i in range(n):
        for j in range(n):
            if mat[i][j]:
                # if some queen already exists at (i,j), check conflict
                if i == row or j == col or abs(i - row) == abs(j - col):
                    return False
    return True


def placeQueens(row, placed, k, mat, result, n, fixed_row, fixed_col):
    # If we've processed all rows
    if row == n:
        if placed == k:
            ans = []
            for i in range(n):
                for j in range(n):
                    if mat[i][j]:
                        ans.append((i + 1, j + 1))
            result.append(ans)
        return

    # If this row already contains the fixed queen, skip trying to place here
    if row == fixed_row:
        placeQueens(row + 1, placed, k, mat, result, n, fixed_row, fixed_col)
        return

    # Try placing a queen in each column of this row
    for col in range(n):
        if mat[row][col]:
            # should not happen except for fixed_row which we skipped; safe-guard
            continue
        if isSafe(mat, row, col, n):
            mat[row][col] = 1
            placeQueens(row + 1, placed + 1, k, mat, result, n, fixed_row, fixed_col)
            mat[row][col] = 0

    # Also try skipping placing a queen in this row (only valid for generalized k <= n)
    # For standard N-Queens (k == n) skipping will make it impossible to reach k, but
    # we keep this for generality (if you want k < n later).
    placeQueens(row + 1, placed, k, mat, result, n, fixed_row, fixed_col)


def nQueensFixed(n, first_row, first_col):
    mat = [[0] * n for _ in range(n)]
    result = []

    # Place the fixed queen (already validated by caller)
    mat[first_row][first_col] = 1

    # Start backtracking from row 0; placed = 1 because we've placed the fixed queen
    placeQueens(0, 1, n, mat, result, n, first_row, first_col)
    return result


if __name__ == "__main__":
    n = int(input("Enter size of matrix (n x n): "))
    print("Enter the position of the first queen (row and column, 1-indexed):")
    r = int(input("Row: ")) - 1
    c = int(input("Column: ")) - 1

    if r < 0 or r >= n or c < 0 or c >= n:
        print("\nInvalid position.")
    else:
        solutions = nQueensFixed(n, r, c)
        if not solutions:
            print(f"\nNo possible arrangement for the given position ({r+1}, {c+1}).")
        else:
            print(f"\nPossible arrangements ({len(solutions)} found) with first queen at ({r+1}, {c+1}):")
            for idx, ans in enumerate(solutions, 1):
                print(f"\nArrangement {idx}:")
                board = [['.'] * n for _ in range(n)]
                for rr, cc in ans:
                    board[rr - 1][cc - 1] = 'Q'
                for row in board:
                    print(" ".join(row))



